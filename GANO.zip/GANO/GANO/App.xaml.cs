﻿using Microsoft.Extensions.DependencyInjection;

namespace GANO
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new Window(new NavigationPage(new Views.AnaSayfa()));
        }
    }
}
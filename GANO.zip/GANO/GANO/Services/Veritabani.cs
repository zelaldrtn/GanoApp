﻿using SQLite;
using GANO.Models;

namespace GANO.Services
{
    public class Veritabani
    {
        SQLiteAsyncConnection db; //veritabanı bağlantısı için değişken

        async Task Init() //veritabanını hazırla
        {
            if (db != null) //bağlantı zaten varsa oluşturma
                return;

            //tel içine gano.db3 oluştur
            string databasePath = Path.Combine(FileSystem.AppDataDirectory, "gano.db3");

            db = new SQLiteAsyncConnection(databasePath);

            await db.CreateTableAsync<Ders>(); //ders tablosunu oluştur
        }

        //tüm dersleri getir
        public async Task<List<Ders>> DersleriGetir()
        {
            await Init();

            return await db.Table<Ders>().ToListAsync();
        }

        //ders ekle
        public async Task<int> DersEkle(Ders ders)
        {
            await Init();

            return await db.InsertAsync(ders);
        }

        //ders güncelle
        public async Task<int> DersGuncelle(Ders ders)
        {
            await Init();

            return await db.UpdateAsync(ders);
        }

        //ders sil
        public async Task<int> DersSil(Ders ders)
        {
            await Init();

            return await db.DeleteAsync(ders);
        }
    }
}

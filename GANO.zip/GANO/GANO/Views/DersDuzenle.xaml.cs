using GANO.Models;
using GANO.Services;

namespace GANO.Views;

public partial class DersDuzenle : ContentPage
{
    Veritabani vt;

    Ders gelenDers;
    public DersDuzenle(Ders ders)
	{
		InitializeComponent();

        vt = new Veritabani();

        gelenDers = ders;

        txtDersKodu.Text = ders.DersKodu;
        txtDersAdi.Text = ders.DersAdi;
        txtHaftalikSaat.Text =
            ders.HaftalikDersSaati.ToString();

        txtAKTS.Text = ders.AKTS.ToString();

        txtDonem.Text = ders.Donem;

        pickerHarfNotu.SelectedItem =
            ders.HarfNotu;

        switchOrtalama.IsToggled =
            ders.OrtalamayaKatilsinMi;
    }

    private async void btnGuncelle_Clicked(object sender, EventArgs e)
	{
        gelenDers.DersKodu = txtDersKodu.Text;

        gelenDers.DersAdi = txtDersAdi.Text;

        gelenDers.HaftalikDersSaati =
            Convert.ToInt32(txtHaftalikSaat.Text);

        gelenDers.AKTS =
            Convert.ToInt32(txtAKTS.Text);

        gelenDers.Donem = txtDonem.Text;

        gelenDers.HarfNotu =
            pickerHarfNotu.SelectedItem.ToString();

        gelenDers.OrtalamayaKatilsinMi =
            switchOrtalama.IsToggled;

        await vt.DersGuncelle(gelenDers);

        await DisplayAlertAsync(
            "Başarılı",
            "Ders güncellendi",
            "Tamam");

        await Navigation.PopAsync();
    }
}
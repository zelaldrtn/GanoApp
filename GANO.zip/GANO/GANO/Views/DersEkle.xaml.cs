using GANO.Models;
using GANO.Services;

namespace GANO.Views;

public partial class DersEkle : ContentPage
{
    Veritabani vt;

    public DersEkle()
    {
        InitializeComponent();

        vt = new Veritabani();
    }

    private async void btnEkle_Clicked(object sender, EventArgs e)
    {
        Ders yeniDers = new Ders()
        {
            DersKodu = txtDersKodu.Text,
            DersAdi = txtDersAdi.Text,
            HaftalikDersSaati = Convert.ToInt32(txtHaftalikSaat.Text),
            AKTS = Convert.ToInt32(txtAKTS.Text),
            Donem = txtDonem.Text,
            HarfNotu = pickerHarfNotu.SelectedItem.ToString(),
            OrtalamayaKatilsinMi = switchOrtalama.IsToggled
        };

        await vt.DersEkle(yeniDers);

        await DisplayAlertAsync("Başarılı", "Ders kaydedildi", "Tamam");

        await Navigation.PopAsync();
    }
}
using GANO.Models;
using GANO.Services;

namespace GANO.Views;

public partial class AnaSayfa : ContentPage
{
    Veritabani vt;
    List<Ders> tumDersler = new List<Ders>();

    public AnaSayfa()
    {
        InitializeComponent();

        vt = new Veritabani();
    }

    protected async override void OnAppearing()
    {
        base.OnAppearing();

        await DersleriYukle();
    }

    async Task DersleriYukle()
    {
        tumDersler = await vt.DersleriGetir();

        dersListesi.ItemsSource = tumDersler;

        GanoHesapla(tumDersler);
    }

    void GanoHesapla(List<Ders> dersler)
    {
        double toplamNot = 0;
        int toplamAKTS = 0;

        foreach (var ders in dersler)
        {
            if (ders.OrtalamayaKatilsinMi == true)
            {
                double katsayi = HarfNotuKatsayi(ders.HarfNotu);

                toplamNot += katsayi * ders.AKTS;

                toplamAKTS += ders.AKTS;
            }
        }

        if (toplamAKTS > 0)
        {
            double gano =
                toplamNot / toplamAKTS;


            // Dashboard GANO
            lblDashBoardGano.Text =
                gano.ToString("0.00");

            // Renk sistemi
            if (gano >= 3)
            {
                lblDashBoardGano.TextColor =
                    Colors.LightGreen;
            }
            else if (gano >= 2)
            {
                lblDashBoardGano.TextColor =
                    Colors.Orange;
            }
            else
            {
                lblDashBoardGano.TextColor =
                    Colors.Red;
            }
        }
        else
        {

            lblDashBoardGano.Text = "0.00";
        }

        int gecenDers =
            dersler.Count(x => x.HarfNotu != "FF");

        double basari =
            dersler.Count > 0
            ? (double)gecenDers / dersler.Count
            : 0;

        lblBasariYuzdesi.Text =
            $"%{(basari * 100):0}";

        lblDashBoardDers.Text =
            dersler.Count.ToString();
    }

    double HarfNotuKatsayi(string harf)
    {
        switch (harf)
        {
            case "AA":
                return 4.0;

            case "BA":
                return 3.5;

            case "BB":
                return 3.0;

            case "CB":
                return 2.5;

            case "CC":
                return 2.0;

            case "DC":
                return 1.5;

            case "DD":
                return 1.0;

            case "FD":
                return 0.5;

            case "FF":
                return 0.0;

            default:
                return 0;
        }
    }

    private async void btnDersEkle_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new DersEkle());
    }

    private async void btnDuzenle_Clicked(object sender, EventArgs e)
    {
        Button? btn = sender as Button;

        int id = Convert.ToInt32(btn.CommandParameter);

        List<Ders> dersler = await vt.DersleriGetir();

        Ders? secilenDers = dersler.FirstOrDefault(x => x.Id == id);

        await Navigation.PushAsync(new DersDuzenle(secilenDers));
    }

    private async void btnSil_Clicked(object sender, EventArgs e)
    {
        Button? btn = sender as Button;

        int id = Convert.ToInt32(btn.CommandParameter);

        List<Ders> dersler = await vt.DersleriGetir();

        Ders? silinecekDers = dersler.FirstOrDefault(x => x.Id == id);

        bool cevap = await DisplayAlertAsync(
            "Uyarı",
            "Bu ders silinsin mi?",
            "Evet",
            "Hayır");

        if (cevap)
        {
            await vt.DersSil(silinecekDers);
            await DersleriYukle();
        }
    }

    private void txtArama_TextChanged(object sender, TextChangedEventArgs e)
    {
        string? text = e.NewTextValue?.ToLower();

        var filtre = tumDersler
            .Where(x => x.DersAdi.ToLower().Contains(text) ||
                        x.DersKodu.ToLower().Contains(text))
            .ToList();

        dersListesi.ItemsSource = filtre;
    }
}
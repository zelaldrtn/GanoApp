﻿using SQLite;

namespace GANO.Models
{
    public class Ders
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string? DersKodu { get; set; }
        public string? DersAdi { get; set; }
        public int HaftalikDersSaati { get; set; }
        public int AKTS { get; set; }
        public bool OrtalamayaKatilsinMi { get; set; }
        public string? Donem { get; set; }
        public string? HarfNotu { get; set; }
    }
}
